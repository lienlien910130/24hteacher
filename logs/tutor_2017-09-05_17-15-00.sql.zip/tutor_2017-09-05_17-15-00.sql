-- MySQL dump 10.14  Distrib 5.5.52-MariaDB, for Linux (x86_64)
--
-- Host: db01.coowo.com    Database: tutor
-- ------------------------------------------------------
-- Server version	5.5.28-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `tutor`
--


--
-- Table structure for table `area`
--

DROP TABLE IF EXISTS `area`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `area` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cid` int(11) NOT NULL,
  `code` int(11) NOT NULL,
  `value` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=375 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `area`
--

LOCK TABLES `area` WRITE;
/*!40000 ALTER TABLE `area` DISABLE KEYS */;
INSERT INTO `area` VALUES (1,1,200,'仁愛區'),(2,1,201,'信義區'),(3,1,202,'中正區'),(4,1,203,'中山區'),(5,1,204,'安樂區'),(6,1,205,'暖暖區'),(7,1,206,'七堵區'),(8,2,100,'中正區'),(9,2,103,'大同區'),(10,2,104,'中山區'),(11,2,105,'松山區'),(12,2,106,'大安區'),(13,2,108,'萬華區'),(14,2,110,'信義區'),(15,2,111,'士林區'),(16,2,112,'北投區'),(17,2,114,'內湖區'),(18,2,115,'南港區'),(19,2,116,'文山區'),(20,3,207,'萬里區'),(21,3,208,'金山區'),(22,3,220,'板橋區'),(23,3,221,'汐止區'),(24,3,222,'深坑區'),(25,3,223,'石碇區'),(26,3,224,'瑞芳區'),(27,3,226,'平溪區'),(28,3,227,'雙溪區'),(29,3,228,'貢寮區'),(30,3,231,'新店區'),(31,3,232,'坪林區'),(32,3,233,'烏來區'),(33,3,234,'永和區'),(34,3,235,'中和區'),(35,3,236,'土城區'),(36,3,237,'三峽區'),(37,3,238,'樹林區'),(38,3,239,'鶯歌區'),(39,3,241,'三重區'),(40,3,242,'新莊區'),(41,3,243,'泰山區'),(42,3,244,'林口區'),(43,3,247,'蘆洲區'),(44,3,248,'五股區'),(45,3,249,'八里區'),(46,3,251,'淡水區'),(47,3,252,'三芝區'),(48,3,253,'石門區'),(49,4,320,'中壢區'),(50,4,324,'平鎮區'),(51,4,325,'龍潭區'),(52,4,326,'楊梅區'),(53,4,327,'新屋區'),(54,4,328,'觀音區'),(55,4,330,'桃園區'),(56,4,333,'龜山區'),(57,4,334,'八德區'),(58,4,335,'大溪區'),(59,4,336,'復興區'),(60,4,337,'大園區'),(61,4,338,'蘆竹區'),(63,6,302,'竹北市'),(64,6,303,'湖口鄉'),(65,6,304,'新豐鄉'),(66,6,305,'新埔鎮'),(67,6,306,'關西鎮'),(68,6,307,'芎林鄉'),(69,6,308,'寶山鄉'),(70,6,310,'竹東鎮'),(71,6,311,'五峰鄉'),(72,6,312,'橫山鄉'),(73,6,313,'尖石鄉'),(74,6,314,'北埔鄉'),(75,6,315,'峨眉鄉'),(76,7,350,'竹南鎮'),(77,7,351,'頭份市'),(78,7,352,'三灣鄉'),(79,7,353,'南庄鄉'),(80,7,354,'獅潭鄉'),(81,7,356,'後龍鎮'),(82,8,400,'中區'),(83,8,401,'東區'),(84,8,402,'南區'),(85,8,403,'西區'),(86,8,404,'北區'),(87,8,406,'北屯區'),(88,8,407,'西屯區'),(89,8,408,'南屯區'),(90,8,411,'太平區'),(91,8,412,'大里區'),(92,8,413,'霧峰區'),(93,8,414,'烏日區'),(94,8,420,'豐原區'),(95,8,421,'后里區'),(96,8,422,'石岡區'),(97,8,423,'東勢區'),(98,8,424,'和平區'),(99,8,426,'新社區'),(100,8,427,'潭子區'),(101,8,428,'大雅區'),(102,8,429,'神岡區'),(103,8,432,'大肚區'),(104,8,433,'沙鹿區'),(105,8,434,'龍井區'),(106,8,435,'梧棲區'),(107,8,436,'清水區'),(108,8,437,'大甲區'),(109,8,438,'外埔區'),(110,8,439,'大安區'),(111,9,500,'彰化市'),(112,9,502,'芬園鄉'),(113,9,503,'花壇鄉'),(114,9,504,'秀水鄉'),(115,9,505,'鹿港鎮'),(116,9,506,'福興鄉'),(117,9,507,'線西鄉'),(118,9,508,'和美鎮'),(119,9,509,'伸港鄉'),(120,9,510,'員林市'),(121,9,511,'社頭鄉'),(122,9,512,'永靖鄉'),(123,9,513,'埔心鄉'),(124,9,514,'溪湖鎮'),(125,9,515,'大村鄉'),(126,9,516,'埔鹽鄉'),(127,9,520,'田中鎮'),(128,9,521,'北斗鎮'),(129,9,522,'田尾鄉'),(130,9,523,'埤頭鄉'),(131,9,524,'溪州鄉'),(132,9,525,'竹塘鄉'),(133,9,526,'二林鎮'),(134,9,527,'大城鄉'),(135,9,528,'芳苑鄉'),(136,9,530,'二水鄉'),(137,10,540,'南投市'),(138,10,541,'中寮鄉'),(139,10,542,'草屯鎮'),(140,10,544,'國姓鄉'),(141,10,545,'埔里鎮'),(142,10,546,'仁愛鄉'),(143,10,551,'名間鄉'),(144,10,552,'集集鎮'),(145,10,553,'水里鄉'),(146,10,555,'魚池鄉'),(147,10,556,'信義鄉'),(148,10,557,'竹山鎮'),(149,10,558,'鹿谷鄉'),(150,11,630,'斗南鎮'),(151,11,631,'大埤鄉'),(152,11,632,'虎尾鎮'),(153,11,633,'土庫鎮'),(154,11,634,'褒忠鄉'),(155,11,635,'東勢鄉'),(156,11,636,'臺西鄉'),(157,11,637,'崙背鄉'),(158,11,638,'麥寮鄉'),(159,11,640,'斗六市'),(160,11,643,'林內鄉'),(161,11,646,'古坑鄉'),(162,11,647,'莿桐鄉'),(163,11,648,'西螺鎮'),(164,11,649,'二崙鄉'),(165,11,651,'北港鎮'),(166,11,652,'水林鄉'),(167,11,653,'口湖鄉'),(168,11,654,'四湖鄉'),(169,11,655,'元長鄉'),(171,13,602,'番路鄉'),(172,13,603,'梅山鄉'),(173,13,604,'竹崎鄉'),(174,13,605,'阿里山鄉'),(175,13,606,'中埔鄉'),(176,13,607,'大埔鄉'),(177,13,608,'水上鄉'),(178,13,611,'鹿草鄉'),(179,13,612,'太保市'),(180,13,613,'朴子市'),(181,13,614,'東石鄉'),(182,13,615,'六腳鄉'),(183,13,616,'新港鄉'),(184,13,621,'民雄鄉'),(185,13,622,'大林鎮'),(186,13,623,'溪口鄉'),(187,13,624,'義竹鄉'),(188,13,625,'布袋鎮'),(189,14,700,'中西區'),(190,14,701,'東區'),(191,14,702,'南區'),(192,14,704,'北區'),(193,14,708,'安平區'),(194,14,709,'安南區'),(195,14,710,'永康區'),(196,14,711,'歸仁區'),(197,14,712,'新化區'),(198,14,713,'左鎮區'),(199,14,714,'玉井區'),(200,14,715,'楠西區'),(201,14,716,'南化區'),(202,14,717,'仁德區'),(203,14,718,'關廟區'),(204,14,719,'龍崎區'),(205,14,720,'官田區'),(206,14,721,'麻豆區'),(207,14,722,'佳里區'),(208,14,723,'西港區'),(209,14,724,'七股區'),(210,14,725,'將軍區'),(211,14,726,'學甲區'),(212,14,727,'北門區'),(213,14,730,'新營區'),(214,14,731,'後壁區'),(215,14,732,'白河區'),(216,14,733,'東山區'),(217,14,734,'六甲區'),(218,14,735,'下營區'),(219,14,736,'柳營區'),(220,14,737,'鹽水區'),(221,14,741,'善化區'),(222,14,742,'大內區'),(223,14,743,'山上區'),(224,14,744,'新市區'),(225,14,745,'安定區'),(226,15,800,'新興區'),(227,15,801,'前金區'),(228,15,802,'苓雅區'),(229,15,803,'鹽埕區'),(230,15,804,'鼓山區'),(231,15,805,'旗津區'),(232,15,806,'前鎮區'),(233,15,807,'三民區'),(234,15,811,'楠梓區'),(235,15,812,'小港區'),(236,15,813,'左營區'),(237,15,814,'仁武區'),(238,15,815,'大社區'),(239,15,820,'岡山區'),(240,15,821,'路竹區'),(241,15,822,'阿蓮區'),(242,15,823,'田寮區'),(243,15,824,'燕巢區'),(244,15,825,'橋頭區'),(245,15,826,'梓官區'),(246,15,827,'彌陀區'),(247,15,828,'永安區'),(248,15,829,'湖內區'),(249,15,830,'鳳山區'),(250,15,831,'大寮區'),(251,15,832,'林園區'),(252,15,833,'鳥松區'),(253,15,840,'大樹區'),(254,15,842,'旗山區'),(255,15,843,'美濃區'),(256,15,844,'六龜區'),(257,15,845,'內門區'),(258,15,846,'杉林區'),(259,15,847,'甲仙區'),(260,15,848,'桃源區'),(261,15,849,'那瑪夏區'),(262,15,851,'茂林區'),(263,15,852,'茄萣區'),(264,16,900,'屏東市'),(265,16,901,'三地門鄉'),(266,16,902,'霧臺鄉'),(267,16,903,'瑪家鄉'),(268,16,904,'九如鄉'),(269,16,905,'里港鄉'),(270,16,906,'高樹鄉'),(271,16,907,'鹽埔鄉'),(272,16,908,'長治鄉'),(273,16,909,'麟洛鄉'),(274,16,911,'竹田鄉'),(275,16,912,'內埔鄉'),(276,16,913,'萬丹鄉'),(277,16,920,'潮州鎮'),(278,16,921,'泰武鄉'),(279,16,922,'來義鄉'),(280,16,923,'萬巒鄉'),(281,16,924,'崁頂鄉'),(282,16,925,'新埤鄉'),(283,16,926,'南州鄉'),(284,16,927,'林邊鄉'),(285,16,928,'東港鎮'),(286,16,929,'琉球鄉'),(287,16,931,'佳冬鄉'),(288,16,932,'新園鄉'),(289,16,940,'枋寮鄉'),(290,16,941,'枋山鄉'),(291,16,942,'春日鄉'),(292,16,943,'獅子鄉'),(293,16,944,'車城鄉'),(294,16,945,'牡丹鄉'),(295,16,946,'恆春鎮'),(296,16,947,'滿州鄉'),(297,17,950,'臺東市'),(298,17,951,'綠島鄉'),(299,17,952,'蘭嶼鄉'),(300,17,953,'延平鄉'),(301,17,954,'卑南鄉'),(302,17,955,'鹿野鄉'),(303,17,956,'關山鎮'),(304,17,957,'海端鄉'),(305,17,958,'池上鄉'),(306,17,959,'東河鄉'),(307,17,961,'成功鎮'),(308,17,962,'長濱鄉'),(309,17,963,'太麻里鄉'),(310,17,964,'金峰鄉'),(311,17,965,'大武鄉'),(312,17,966,'達仁鄉'),(313,18,970,'花蓮市'),(314,18,971,'新城鄉'),(315,18,972,'秀林鄉'),(316,18,973,'吉安鄉'),(317,18,974,'壽豐鄉'),(318,18,975,'鳳林鎮'),(319,18,976,'光復鄉'),(320,18,977,'豐濱鄉'),(321,18,978,'瑞穗鄉'),(322,18,979,'萬榮鄉'),(323,18,981,'玉里鎮'),(324,18,982,'卓溪鄉'),(325,18,983,'富里鄉'),(326,19,260,'宜蘭市'),(327,19,261,'頭城鎮'),(328,19,262,'礁溪鄉'),(329,19,263,'壯圍鄉'),(330,19,264,'圓山鄉'),(331,19,265,'羅東鎮'),(332,19,266,'三星鄉'),(333,19,267,'大同鄉'),(334,19,268,'五結鄉'),(335,19,269,'冬山鄉'),(336,19,270,'蘇澳鎮'),(337,19,272,'南澳鄉'),(338,19,290,'釣魚臺'),(339,20,880,'馬公市'),(340,20,881,'西嶼鄉'),(341,20,882,'望安鄉'),(342,20,883,'七美鄉'),(343,20,884,'白沙鄉'),(344,20,885,'湖西鄉'),(345,21,890,'金沙鎮'),(346,21,891,'金湖鎮'),(347,21,892,'金寧鄉'),(348,21,893,'金城鎮'),(349,21,894,'烈嶼鄉'),(350,21,896,'烏坵鄉'),(351,22,209,'南竿鄉'),(352,22,210,'北竿鄉'),(353,22,211,'莒光鄉'),(354,22,212,'東引鄉'),(355,12,600,'東區'),(356,12,600,'西區'),(357,5,300,'東區'),(358,5,300,'北區'),(359,5,300,'香山區'),(360,15,817,'東沙群島'),(361,15,819,'南沙群島'),(362,7,357,'通霄鎮'),(363,7,358,'苑裡鎮'),(364,7,360,'苗栗市'),(365,7,361,'造橋鄉'),(366,7,362,'頭屋鄉'),(367,7,363,'公館鄉'),(368,7,364,'大湖鄉'),(369,7,365,'泰安鄉'),(370,7,366,'銅鑼鄉'),(371,7,367,'三義鄉'),(372,7,368,'西湖鄉'),(373,7,369,'卓蘭鎮');
/*!40000 ALTER TABLE `area` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `case_category`
--

DROP TABLE IF EXISTS `case_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `case_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `val` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `case_category`
--

LOCK TABLES `case_category` WRITE;
/*!40000 ALTER TABLE `case_category` DISABLE KEYS */;
INSERT INTO `case_category` VALUES (1,'å­¸ç”Ÿå§“å'),(2,'ç¨‹åº¦èªªæ˜Ž'),(3,'ç›®çš„'),(4,'èª²ç¨‹'),(5,'æ–¹å¼'),(6,'äººæ•¸'),(7,'åœ°é»ž'),(8,'ç¯„åœ'),(9,'æ™‚é–“'),(10,'é–‹å§‹æ™‚é–“'),(11,'ç¶“é©—'),(12,'è€å¸«èº«åˆ†'),(13,'å­¸æ ¡'),(14,'ç§‘ç³»'),(15,'æœ€ä½Ž'),(16,'æœ€é«˜'),(17,'å…¶ä»–'),(18,'è·¯æ¨™'),(19,'åœ°å€'),(20,'å­¸ç”Ÿèº«åˆ†'),(21,'å­¸ç”Ÿæ€§åˆ¥'),(22,'å­¸ç”Ÿå­¸æ ¡');
/*!40000 ALTER TABLE `case_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `case_list`
--

DROP TABLE IF EXISTS `case_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `case_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cid` int(11) NOT NULL,
  `caid` int(11) NOT NULL,
  `val` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=556 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `case_list`
--

LOCK TABLES `case_list` WRITE;
/*!40000 ALTER TABLE `case_list` DISABLE KEYS */;
INSERT INTO `case_list` VALUES (468,22,9,'週三,900,1000'),(469,22,13,'國立臺灣海洋大學'),(470,22,1,'DWDWQ'),(471,22,2,'WQDWQD'),(472,22,3,'課業輔導'),(473,22,4,'美術藝術建築'),(474,22,5,'函授'),(475,22,6,'20'),(476,22,7,'外面上課'),(477,22,8,'上短期(2個月以內)'),(478,22,10,'立即'),(479,22,11,'無經驗'),(480,22,12,'不拘'),(481,22,14,'ADQWD'),(482,22,15,'1300'),(483,22,16,'1500'),(484,22,17,'ASDQWD'),(485,22,18,'SADD'),(486,22,19,'南投縣埔里鎮'),(487,22,20,'高中二年級'),(488,22,21,'女'),(489,22,22,'ASD'),(490,23,9,'週三,1330,1430'),(491,23,13,'國立彰化師範大學'),(492,23,1,'efef'),(493,23,2,'fwefef'),(494,23,3,'課業輔導'),(495,23,4,'音樂長笛'),(496,23,5,'面對面上課'),(497,23,6,'10'),(498,23,7,'外面上課'),(499,23,8,'上短期(2個月以內)'),(500,23,10,'立即'),(501,23,11,'無經驗'),(502,23,12,'上班族'),(503,23,14,'sfef'),(504,23,15,'1400'),(505,23,16,'1500'),(506,23,17,'sdfwe'),(507,23,18,'sdfwe'),(508,23,19,'桃園市龍潭區'),(509,23,20,'國小六年級'),(510,23,21,'女'),(511,23,22,'ewfwe'),(512,24,9,'週二,800,1000'),(513,24,13,'國立清華大學'),(514,24,1,'劉怡萱'),(515,24,2,'1111122222222233456789YYTFTFCGCHGFSCGSGFDXGDGFDXGFDXDFXFDXFXDBXFXFD FXGFDCGFVHGFVGHGHGNGVGFBGVHGHFGTVFGDCDFXDCFXFDXGFDXFDXDGFXGFDXFDXGFXFXGFXRXFCCGNBFHGVBNXDCFGVHBJFVGHBJVJGCHVGHJJHVGVJHVJHVHJVGJHGHJJ'),(516,24,3,'升學考試'),(517,24,4,'國文國高中作文'),(518,24,5,'面對面上課'),(519,24,6,'20'),(520,24,7,'家裡上課'),(521,24,8,'上短期(2個月以內)'),(522,24,10,'立即'),(523,24,11,'五年以上'),(524,24,12,'補習班老師/家教'),(525,24,14,'中文 '),(526,24,15,'600'),(527,24,16,'900'),(528,24,17,'6tcyiuhrulehlehtieksdnfsdnfj.herhknknckcnkj.dfkejnfkjefnkjdsfnkjsfnkjenflkjdnsfnksdjfnjkdkfnkdsnfkdjsfnks.nfksdnfkjsfns.kjfn.dskjfnkdnfkjdsnfkjdsnfkjdsfnkdjsfnkdjsfnksnfksdnfksjdnfkdsjnfkjdsnfkjsdnfkd'),(529,24,18,'北車 '),(530,24,19,'臺北市中正區'),(531,24,20,'高中二年級'),(532,24,21,'女'),(533,24,22,'中山女高 '),(534,25,9,'週四,1400,1500'),(535,25,13,'國立中央大學'),(536,25,1,'dfqwf'),(537,25,2,'wqdqw\r\nsqw\r\n\r\nsadwqd\r\nsaljfoqwhofy92\r\nwqojdojwqojfpoqwjpofop2h1of\r\n\r\nqwhfi2h1iri'),(538,25,3,'個人進修'),(539,25,4,'國文高普考國文'),(540,25,5,'面對面上課'),(541,25,6,'20'),(542,25,7,'外面上課'),(543,25,8,'上短期(2個月以內)'),(544,25,10,'立即'),(545,25,11,'一~三年'),(546,25,12,'上班族'),(547,25,14,'qwdqwdqe'),(548,25,15,'1400'),(549,25,16,'1500'),(550,25,17,'wqdoiqwhdoi\r\nlkafhqwhio\r\n\r\n\r\nqwdjoo2ueoo\r\nndakskdhkqw\r\nkhfiqwhifgui21ir\r\n\r\nndklqwkfkqwgf'),(551,25,18,'fwfe'),(552,25,19,'基隆市信義區'),(553,25,20,'國中二年級'),(554,25,21,'女'),(555,25,22,'wqdwq');
/*!40000 ALTER TABLE `case_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cases`
--

DROP TABLE IF EXISTS `cases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `numbers` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `phone` varchar(11) NOT NULL,
  `addtime` varchar(255) NOT NULL,
  `lastedit` varchar(255) NOT NULL,
  `applicants` int(11) NOT NULL,
  `views` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `apply` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cases`
--

LOCK TABLES `cases` WRITE;
/*!40000 ALTER TABLE `cases` DISABLE KEYS */;
INSERT INTO `cases` VALUES (22,213050022,81,'SAD','0911111111','2017-09-05 11:38:14','2017-09-05 11:38:14',0,0,0,0),(23,588050023,81,'sdwf','0911111111','2017-09-05 11:59:14','2017-09-05 11:59:14',0,0,0,0),(24,136050024,86,'陳文琳 ','0932756480','2017-09-05 12:03:43','2017-09-05 12:03:43',0,0,0,0),(25,121050025,81,'wqdw','0911111111','2017-09-05 12:35:42','2017-09-05 12:35:42',0,0,0,0);
/*!40000 ALTER TABLE `cases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `certification`
--

DROP TABLE IF EXISTS `certification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `certification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `names` varchar(255) NOT NULL,
  `paths` varchar(255) NOT NULL,
  `types` int(11) NOT NULL,
  `checks` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `addtime` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `certification`
--

LOCK TABLES `certification` WRITE;
/*!40000 ALTER TABLE `certification` DISABLE KEYS */;
INSERT INTO `certification` VALUES (24,'0','0',0,0,81,'2017-09-05 12:27:13');
/*!40000 ALTER TABLE `certification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `city`
--

DROP TABLE IF EXISTS `city`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `city` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cityvalue` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `city`
--

LOCK TABLES `city` WRITE;
/*!40000 ALTER TABLE `city` DISABLE KEYS */;
INSERT INTO `city` VALUES (1,'基隆市'),(2,'臺北市'),(3,'新北市'),(4,'桃園市'),(5,'新竹市'),(6,'新竹縣'),(7,'苗栗縣'),(8,'臺中市'),(9,'彰化縣'),(10,'南投縣'),(11,'雲林縣'),(12,'嘉義市'),(13,'嘉義縣'),(14,'臺南市'),(15,'高雄市'),(16,'屏東縣'),(17,'臺東縣'),(18,'花蓮縣'),(19,'宜蘭縣'),(20,'澎湖縣'),(21,'金門縣'),(22,'連江縣');
/*!40000 ALTER TABLE `city` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clouds`
--

DROP TABLE IF EXISTS `clouds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clouds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `titles` varchar(255) NOT NULL,
  `hre` varchar(255) NOT NULL,
  `types` int(11) NOT NULL,
  `names` varchar(255) NOT NULL,
  `names_all` varchar(255) NOT NULL,
  `hre_all` varchar(255) NOT NULL,
  `prices` int(11) NOT NULL,
  `checks` int(11) NOT NULL,
  `addtime` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clouds`
--

LOCK TABLES `clouds` WRITE;
/*!40000 ALTER TABLE `clouds` DISABLE KEYS */;
/*!40000 ALTER TABLE `clouds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `inid` int(11) NOT NULL,
  `val` varchar(255) NOT NULL,
  `edittime` varchar(255) NOT NULL,
  `num` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comments`
--

LOCK TABLES `comments` WRITE;
/*!40000 ALTER TABLE `comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `country`
--

DROP TABLE IF EXISTS `country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `country` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `val` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `country`
--

LOCK TABLES `country` WRITE;
/*!40000 ALTER TABLE `country` DISABLE KEYS */;
INSERT INTO `country` VALUES (1,'美國'),(2,'加拿大'),(3,'英國'),(4,'德國'),(5,'法國'),(6,'義大利'),(7,'西班牙'),(8,'澳洲'),(9,'紐西蘭'),(10,'日本'),(11,'韓國'),(12,'葡萄牙'),(13,'非洲'),(14,'東南亞'),(15,'其他亞洲'),(16,'中美洲'),(17,'其他南美'),(18,'其它國家'),(19,'無');
/*!40000 ALTER TABLE `country` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `downfiles`
--

DROP TABLE IF EXISTS `downfiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `downfiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `imgs` varchar(255) NOT NULL,
  `objects` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `name` varchar(255) NOT NULL,
  `paths` varchar(255) NOT NULL,
  `imgname` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `downfiles`
--

LOCK TABLES `downfiles` WRITE;
/*!40000 ALTER TABLE `downfiles` DISABLE KEYS */;
INSERT INTO `downfiles` VALUES (1,'面試記錄表','downfiles/12.jpg','案主家長','提供案主家長簡單好用的「家教面試記錄表」，包含面試項目，試教評分及結果。讓您客觀地挑選出最合適的家教老師！提供案主家長簡單好用的「家教面試記錄表」，包含面試項目，試教評分及結果。讓您客觀地挑選出最合適的家教老師！','新增 Microsoft Word 文件.docx','downfiles/06-07-2017-09-57-06-新增 Microsoft Word 文件.docx',''),(2,'家教聘僱合約書','downfiles/2.jpg','老師及案主家長','家教品質須要家長及老師共同維持。建議在正式上課前可簽訂「聘僱合約書」，保障雙方權益。(※合約內容可依個案修改，敬請多加利用！)家教品質須要家長及老師共同維持。建議在正式上課前可簽訂「聘僱合約書」，保障雙方權益。(※合約內容可依個案修改，敬請多加利用！)','新增 Microsoft Word 文件.docx','downfiles/06-07-2017-09-57-06-新增 Microsoft Word 文件.docx',''),(3,'課程規劃表','downfiles/3.jpg','老師','事前規劃好教學計劃，時時檢視及調整進度，避免段考前需猛加課而影響效果，也可以展現老師的專業形象，請多多利用！事前規劃好教學計劃，時時檢視及調整進度，避免段考前需猛加課而影響效果，也可以展現老師的專業形象，請多多利用！','新增 Microsoft Word 文件.docx','downfiles/06-07-2017-09-57-06-新增 Microsoft Word 文件.docx',''),(4,'教學日誌','downfiles/4.jpg','老師及案主家長','家教多採時薪制，上課時數及結算並無制式，如何確保薪資數字無誤？家教網提供簡單好用的「上課簽到表」，老師可以在每次下課後，請家長或案主簽名確認，保障雙方權益。家教多採時薪制，上課時數及結算並無制式，如何確保薪資數字無誤？家教網提供簡單好用的「上課簽到表」，老師可以在每次下課後，請家長或案主簽名確認，保障雙方權益。','新增 Microsoft Word 文件.docx','downfiles/06-07-2017-09-57-06-新增 Microsoft Word 文件.docx','');
/*!40000 ALTER TABLE `downfiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `experience`
--

DROP TABLE IF EXISTS `experience`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `experience` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `val` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `experience`
--

LOCK TABLES `experience` WRITE;
/*!40000 ALTER TABLE `experience` DISABLE KEYS */;
INSERT INTO `experience` VALUES (1,'無經驗'),(2,'一年以下'),(3,'一年上下~三年以下'),(4,'三年以上'),(5,'五年以下'),(6,'五年以上');
/*!40000 ALTER TABLE `experience` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `favorite`
--

DROP TABLE IF EXISTS `favorite`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `favorite` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `types` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `favorite`
--

LOCK TABLES `favorite` WRITE;
/*!40000 ALTER TABLE `favorite` DISABLE KEYS */;
INSERT INTO `favorite` VALUES (7,24,85,1);
/*!40000 ALTER TABLE `favorite` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `identity`
--

DROP TABLE IF EXISTS `identity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `identity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `val` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `identity`
--

LOCK TABLES `identity` WRITE;
/*!40000 ALTER TABLE `identity` DISABLE KEYS */;
INSERT INTO `identity` VALUES (1,'無工作'),(2,'上班族'),(3,'在校生'),(4,'教師'),(5,'補習班老師/家教');
/*!40000 ALTER TABLE `identity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `interview`
--

DROP TABLE IF EXISTS `interview`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `interview` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `reid` int(11) NOT NULL,
  `rid` int(11) NOT NULL,
  `caid` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  `source` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `edittime` varchar(255) CHARACTER SET latin1 NOT NULL,
  `addtime` varchar(255) NOT NULL,
  `typeedit` varchar(255) NOT NULL,
  `salary` int(11) NOT NULL,
  `accept` int(11) NOT NULL,
  `comment` int(11) NOT NULL,
  `accepttime` varchar(255) NOT NULL,
  `pay` int(11) NOT NULL,
  `paytime` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `interview`
--

LOCK TABLES `interview` WRITE;
/*!40000 ALTER TABLE `interview` DISABLE KEYS */;
/*!40000 ALTER TABLE `interview` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `languages`
--

DROP TABLE IF EXISTS `languages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `languages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `val` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `languages`
--

LOCK TABLES `languages` WRITE;
/*!40000 ALTER TABLE `languages` DISABLE KEYS */;
INSERT INTO `languages` VALUES (1,'全民英檢'),(2,'TOEIC'),(3,'TOEIC SW'),(4,'TOEFL'),(5,'IELTS'),(6,'日文檢定'),(7,'韓文檢定'),(8,'其他'),(9,'無');
/*!40000 ALTER TABLE `languages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lessions`
--

DROP TABLE IF EXISTS `lessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sid` varchar(255) CHARACTER SET latin1 NOT NULL,
  `val` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1404 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lessions`
--

LOCK TABLES `lessions` WRITE;
/*!40000 ALTER TABLE `lessions` DISABLE KEYS */;
INSERT INTO `lessions` VALUES (1,'1','伴讀'),(2,'2','保姆'),(3,'3','國高中國文'),(4,'3','國高中作文'),(5,'3','高普考國文'),(6,'3','高普考國文申論題'),(7,'3','大專以上國文'),(8,'3','國文論文、報告撰寫指導'),(9,'3','履歷撰寫指導'),(10,'3','國語文競賽指導'),(11,'4','國高中英文'),(12,'4','國高中英文作文'),(13,'4','高普考英文'),(14,'4','高普考英文作文'),(15,'4','大專以上英文'),(16,'4','留學考試英文'),(17,'4','英文論文、報告撰寫指導'),(18,'4','英文履歷撰寫指導或翻譯'),(19,'4','英文會話及口語表達'),(20,'5','國高中數學'),(21,'5','大專以上數學'),(22,'5','科展數學'),(23,'5','其他數學'),(24,'6','國中理化'),(25,'6','高中物理'),(26,'6','高中化學'),(27,'6','大專以上理科'),(28,'6','科展物理、化學'),(29,'6','科學實驗指導'),(30,'6','國高中生物地科'),(31,'6','其他理科'),(32,'7','國高中歷史'),(33,'7','國高中地理'),(34,'7','國高中公民'),(35,'7','高普考社會'),(36,'7','大專以上社會科學'),(37,'7','其他社會'),(38,'8','閩南語'),(39,'8','客家話'),(40,'8','原住民語'),(41,'9','法文'),(42,'9','德文'),(43,'9','西班牙文'),(44,'9','其他歐語'),(45,'9','日文'),(46,'9','韓文'),(47,'9','泰文'),(48,'9','印尼文'),(49,'9','越南文'),(50,'9','其他外語'),(51,'10','鋼琴'),(52,'10','小提琴'),(53,'10','長笛'),(54,'10','吉他'),(55,'10','爵士鼓'),(56,'10','口琴'),(57,'10','琵琶'),(58,'10','二胡'),(59,'10','古琴'),(60,'10','洞簫'),(61,'10','古箏'),(62,'10','聲樂'),(63,'10','樂理'),(64,'10','其他打擊樂'),(65,'10','其他弦樂'),(66,'10','其他管樂'),(67,'11','藝術史'),(68,'11','書法'),(69,'11','水墨'),(70,'11','素描'),(71,'11','插畫'),(72,'11','油畫'),(73,'11','漫畫'),(74,'11','陶藝'),(75,'11','建築'),(76,'11','平面設計'),(77,'11','工業設計'),(78,'11','空間設計'),(79,'11','其他藝術'),(80,'12','游泳'),(81,'12','衝浪'),(82,'12','帆船'),(83,'12','其他水上活動'),(84,'12','籃球'),(85,'12','足球'),(86,'12','棒球'),(87,'12','壘球'),(88,'12','網球'),(89,'12','其他球類'),(90,'12','跆拳道'),(91,'12','柔道'),(92,'12','太極'),(93,'12','空手道'),(94,'12','其他拳法'),(95,'12','瑜珈'),(96,'12','扯鈴'),(97,'13','入門基礎'),(98,'13','程式語言'),(99,'13','電腦繪圖'),(100,'13','資料庫'),(101,'13','office系列'),(102,'13','網站架設'),(103,'13','網頁設計'),(104,'13','動畫製作'),(105,'13','資料庫'),(106,'13','統計軟體'),(107,'13','手機app開發'),(108,'13','其他電腦'),(109,'14','街舞'),(110,'14','土風舞'),(111,'14','國標舞'),(112,'14','芭蕾舞'),(113,'14','民族舞蹈'),(114,'14','拉丁有氧'),(115,'14','肚皮舞'),(116,'14','爵士舞'),(117,'14','其他舞蹈'),(118,'15','工程數學'),(119,'15','微積分'),(120,'15','會計學'),(121,'15','經濟學'),(122,'15','統計學'),(123,'15','護理學'),(124,'15','電子學'),(125,'15','電機學'),(126,'15','其他專業科目'),(127,'16','甜點製作'),(128,'16','烹飪'),(129,'16','縫紉拼布'),(130,'16','羊毛氈'),(131,'16','攝影'),(132,'16','唱歌'),(133,'16','編織毛線'),(134,'16','金工'),(135,'16','木工'),(136,'16','其他興趣'),(137,'17','美甲'),(138,'17','化妝'),(139,'17','編劇'),(140,'17','中、大型駕駛與重機'),(141,'17','演戲'),(142,'17','電子商務'),(143,'17','行銷管理'),(144,'17','批貨採購'),(145,'17','其他');
/*!40000 ALTER TABLE `lessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `level`
--

DROP TABLE IF EXISTS `level`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `level` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lid` int(11) NOT NULL,
  `val` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `level`
--

LOCK TABLES `level` WRITE;
/*!40000 ALTER TABLE `level` DISABLE KEYS */;
INSERT INTO `level` VALUES (1,1,'初級'),(2,1,'中級'),(3,1,'中高級'),(4,1,'高級'),(5,2,'橘色(10~215)'),(6,2,'棕色(220~465)'),(7,2,'綠色(470~725)'),(8,2,'藍色(730~855)'),(9,2,'金色(860~990)'),(10,3,'TOEIC SW'),(11,4,'棕色(460分以上)'),(12,4,'銀色(543分以上)'),(13,4,'金色(627分以上)'),(14,5,'一級'),(15,5,'二級'),(16,5,'三級'),(17,5,'四級'),(18,5,'五級'),(19,5,'六級'),(20,5,'七級'),(21,5,'八級'),(22,5,'九級'),(23,6,'N1'),(24,6,'N2'),(25,6,'N3'),(26,6,'N4'),(27,6,'N5'),(28,7,'1級'),(29,7,'2級'),(30,7,'3級'),(31,7,'4級'),(32,7,'5級'),(33,7,'6級'),(34,8,'其他'),(35,9,'無');
/*!40000 ALTER TABLE `level` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mailer`
--

DROP TABLE IF EXISTS `mailer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mailer` (
  `id` varchar(11) NOT NULL,
  `mailac` varchar(255) NOT NULL,
  `mailpa` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mailer`
--

LOCK TABLES `mailer` WRITE;
/*!40000 ALTER TABLE `mailer` DISABLE KEYS */;
INSERT INTO `mailer` VALUES ('1','lily@dgsense.com','lily53949572');
/*!40000 ALTER TABLE `mailer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `numbers` varchar(255) CHARACTER SET latin1 NOT NULL,
  `account` varchar(255) CHARACTER SET latin1 NOT NULL,
  `password` varchar(255) CHARACTER SET latin1 NOT NULL,
  `type` varchar(255) CHARACTER SET latin1 NOT NULL,
  `lastlogin` varchar(255) CHARACTER SET latin1 NOT NULL,
  `getpasstime` varchar(255) NOT NULL,
  `getid` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` VALUES (1,'00000000','admin@admin.com','1a73e8d9b88515845eabc8dbcb1caf32','0','2017-08-02 09:56:24','',''),(81,'051048081','chinejo3ejo3@yahoo.com.tw','0qjsdpfb0','2','2017-09-05 16:08:28','','1378438115572670'),(82,'052098082','elainebear0414@gmail.com','0qjsdpgm0','3','2017-09-05 11:45:15','','100149321431355753819'),(83,'051687083','ksbcboy@gmail.com','0qjsdpfb0','2','2017-09-05 11:45:33','','10155675403594099'),(84,'051092084','iesha828@gmail.com','0qjsdpfb0','2','2017-09-05 11:50:03','','1245650028894665'),(85,'051790085','r97145006@ntu.edu.tw','0qjsdpfb0','2','2017-09-05 11:50:00','','1561022513908840'),(86,'051176086','evil828evil828@gmail.com','0qjsdpfb0','2','2017-09-05 11:56:36','','1827741550571202');
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_category`
--

DROP TABLE IF EXISTS `member_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_category`
--

LOCK TABLES `member_category` WRITE;
/*!40000 ALTER TABLE `member_category` DISABLE KEYS */;
INSERT INTO `member_category` VALUES (1,'姓名'),(2,'性別'),(3,'生日'),(4,'地址'),(5,'照片'),(6,'電話'),(7,'信箱'),(8,'身份證字號');
/*!40000 ALTER TABLE `member_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_list`
--

DROP TABLE IF EXISTS `member_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `cid` varchar(255) CHARACTER SET latin1 NOT NULL,
  `val` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=579 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_list`
--

LOCK TABLES `member_list` WRITE;
/*!40000 ALTER TABLE `member_list` DISABLE KEYS */;
INSERT INTO `member_list` VALUES (1,40,'1',''),(2,40,'2',''),(3,40,'3',''),(4,40,'4',''),(5,40,'5',''),(6,40,'6',''),(7,40,'7','admin@admin.com'),(8,40,'8',''),(531,81,'3','2017-09-05'),(532,81,'4','822高雄市阿蓮區'),(533,81,'5','profile/05-09-2017-11-37-29-大頭照.png'),(534,81,'6','0911111111'),(535,81,'8','m222694054'),(536,81,'1','劉馨蓮'),(537,81,'2','女'),(538,81,'7','chinejo3ejo3@yahoo.com.tw'),(539,82,'1',''),(540,82,'2',''),(541,82,'3',''),(542,82,'4',''),(543,82,'5',''),(544,82,'6',''),(545,82,'8',''),(546,82,'7','elainebear0414@gmail.com'),(547,83,'3',''),(548,83,'4',''),(549,83,'5',''),(550,83,'6',''),(551,83,'8',''),(552,83,'1','許迺赫'),(553,83,'2','男'),(554,83,'7','ksbcboy@gmail.com'),(555,84,'3',''),(556,84,'4',''),(557,84,'5',''),(558,84,'6',''),(559,84,'8',''),(560,84,'1','Yisuan Liu'),(561,84,'2','女'),(562,84,'7','iesha828@gmail.com'),(563,85,'3','2014-09-11'),(564,85,'4','201基隆市信義區'),(565,85,'5','profile/05-09-2017-11-53-54-基礎文字能力.jpg'),(566,85,'6','0925666666'),(567,85,'8','i200089097'),(568,85,'1','Yi-Ling Chen'),(569,85,'2','女'),(570,85,'7','r97145006@ntu.edu.tw'),(571,86,'3','1986-08-28'),(572,86,'4','100臺北市中正區'),(573,86,'5','profile/123.jpg'),(574,86,'6','0932756480'),(575,86,'8','T223609082'),(576,86,'1','I-Hsuan Liu'),(577,86,'2','女'),(578,86,'7','evil828evil828@gmail.com');
/*!40000 ALTER TABLE `member_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `news`
--

DROP TABLE IF EXISTS `news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `val` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `types` int(11) NOT NULL,
  `issend` int(11) NOT NULL,
  `sendtime` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `news`
--

LOCK TABLES `news` WRITE;
/*!40000 ALTER TABLE `news` DISABLE KEYS */;
INSERT INTO `news` VALUES (6,'6.html','efwefwf',1,1,'2017-09-04 16:43:54');
/*!40000 ALTER TABLE `news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `newsletter`
--

DROP TABLE IF EXISTS `newsletter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `newsletter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `casespa` int(11) DEFAULT NULL,
  `teachpa` int(11) DEFAULT NULL,
  `webpa` int(11) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `newsletter`
--

LOCK TABLES `newsletter` WRITE;
/*!40000 ALTER TABLE `newsletter` DISABLE KEYS */;
INSERT INTO `newsletter` VALUES (4,'lienlien910130@gmail.com',1,0,1,'11111111'),(7,'lily@dgsense.com',1,0,0,'11111111');
/*!40000 ALTER TABLE `newsletter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notes`
--

DROP TABLE IF EXISTS `notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  `cuid` int(11) NOT NULL,
  `addtime` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notes`
--

LOCK TABLES `notes` WRITE;
/*!40000 ALTER TABLE `notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `object`
--

DROP TABLE IF EXISTS `object`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `object` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `val` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object`
--

LOCK TABLES `object` WRITE;
/*!40000 ALTER TABLE `object` DISABLE KEYS */;
INSERT INTO `object` VALUES (1,'學齡前兒童'),(2,'國小生'),(3,'國中生'),(4,'高中生'),(5,'大學生'),(6,'社會人士');
/*!40000 ALTER TABLE `object` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `page`
--

DROP TABLE IF EXISTS `page`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `page` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `val` text NOT NULL,
  `title` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `page`
--

LOCK TABLES `page` WRITE;
/*!40000 ALTER TABLE `page` DISABLE KEYS */;
INSERT INTO `page` VALUES (2,'privacy.html','隱私權保護'),(3,'teacher.html','老師服務說明'),(4,'cases.html','案主服務說明'),(6,'regi.html','會員註冊服務條款'),(7,'aboutus.html','關於我們');
/*!40000 ALTER TABLE `page` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `parents`
--

DROP TABLE IF EXISTS `parents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `parents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `paths` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `val` text NOT NULL,
  `addtime` varchar(255) NOT NULL,
  `contitle` varchar(255) NOT NULL,
  `views` int(11) NOT NULL,
  `types` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `parents`
--

LOCK TABLES `parents` WRITE;
/*!40000 ALTER TABLE `parents` DISABLE KEYS */;
INSERT INTO `parents` VALUES (2,'about_us_b.jpg','article/20-07-2017-05-05-15-about_us_b.jpg','免經驗的老師','時間飛逝，不知不覺中當老師也十多年了。每當看到身旁剛畢業的新手老師時，就會想趁從前那個帶點青澀，又充滿傻呼呼...','<p>測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測<span style=\"font-size:36px\">試中測試中測試中測試中測試中測試中測試中試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中</span></p>\r\n','2017-07-20 05:05:15','0809',10,0),(3,'about_us_b.jpg','article/20-07-2017-05-06-23-about_us_b.jpg','免經驗的好老師','時間飛逝，不知不覺中當老師也十多年了。每當看到身旁剛畢業的新手老師時，就會想趁從前那個帶點青澀，又充滿傻呼呼...2','<p>測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測&lt;span style=&quot;font-size:36px&quot;&gt;試中測試中測試中測試中測試中測試中測試中試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中測試中</p>\r\n','2017-07-20 05:06:23','談經驗，你我都行',5,0),(4,'about_us_b.jpg','article/20-07-2017-05-06-51-about_us_b.jpg','免經驗的好老師3','時間飛逝，不知不覺中當老師也十多年了。每當看到身旁剛畢業的新手老師時，就會想趁從前那個帶點青澀，又充滿傻呼呼...3','<p>測試中</p>\r\n','2017-07-20 05:06:51','談經驗，你我都行',15,0),(6,'about_us_b.jpg','article/09-08-2017-10-13-56-about_us_b.jpg','免經驗的好老師4','時間飛逝，不知不覺中當老師也十多年了。每當看到身旁剛畢業的新手老師時，就會想趁從前那個帶點青澀，又充滿傻呼呼...3','<p>efewfwe</p>\r\n','2017-08-09 10:13:56','談經驗，你我都行',5,0);
/*!40000 ALTER TABLE `parents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `picture`
--

DROP TABLE IF EXISTS `picture`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `picture` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `paths` varchar(255) NOT NULL,
  `types` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `picture`
--

LOCK TABLES `picture` WRITE;
/*!40000 ALTER TABLE `picture` DISABLE KEYS */;
INSERT INTO `picture` VALUES (44,'indexpic/13-07-2017-05-29-31-home_page_a_350 X250_1.png',2,'home_page_a_350 X250_1.png',''),(45,'indexpic/13-07-2017-05-29-46-home_page_a_350 X250_2.png',3,'home_page_a_350 X250_2.png',''),(46,'indexpic/13-07-2017-05-29-55-home_page_a_350 X250_3.png',4,'home_page_a_350 X250_3.png',''),(47,'indexpic/13-07-2017-05-30-09-home_page_b_456X410_1.png',5,'home_page_b_456X410_1.png',''),(49,'indexpic/13-07-2017-09-23-01-home_page_a_600X450.png',7,'home_page_a_600X450.png',''),(50,'indexpic/13-07-2017-09-23-12-home_page_a_420X380.png',8,'home_page_a_420X380.png',''),(51,'indexpic/13-07-2017-09-22-33-home_page_a_420X570.png',6,'home_page_a_420X570.png',''),(52,'indexpic/13-07-2017-09-26-17-home_page_a_510X347_1.png',9,'home_page_a_510X347_1.png',''),(53,'indexpic/13-07-2017-09-26-23-home_page_a_510X347_2.png',10,'home_page_a_510X347_2.png',''),(54,'indexpic/13-07-2017-09-26-29-home_page_a_510X347_3.png',11,'home_page_a_510X347_3.png',''),(55,'indexpic/13-07-2017-10-06-09-banner_a.jpg',1,'banner_a.jpg',''),(56,'indexpic/13-07-2017-10-06-15-banner_b.jpg',1,'banner_b.jpg',''),(57,'indexpic/13-07-2017-10-06-21-banner_c.jpg',1,'banner_c.jpg',''),(58,'indexpic/13-07-2017-10-06-27-banner_d.jpg',1,'banner_d.jpg',''),(59,'indexpic/20-07-2017-07-48-06-photo_330X300_A.jpg',12,'photo_330X300_A.jpg',''),(60,'indexpic/20-07-2017-07-49-03-photo_330X300_B.jpg',13,'photo_330X300_B.jpg',''),(61,'indexpic/20-07-2017-07-49-13-photo_330X300_C.jpg',14,'photo_330X300_C.jpg','');
/*!40000 ALTER TABLE `picture` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `power`
--

DROP TABLE IF EXISTS `power`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `power` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `cases` int(11) NOT NULL,
  `resumes` int(11) NOT NULL,
  `invite` int(11) NOT NULL,
  `application` int(11) NOT NULL,
  `updatetime` varchar(255) NOT NULL,
  `certification` varchar(255) NOT NULL,
  `invitenum` int(11) NOT NULL,
  `applicnum` int(11) NOT NULL,
  `lasttype` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `power`
--

LOCK TABLES `power` WRITE;
/*!40000 ALTER TABLE `power` DISABLE KEYS */;
INSERT INTO `power` VALUES (58,81,1,1,1,1,'2017-09-05 12:35:42','0',0,0,2),(59,82,1,1,1,1,'','0',0,0,0),(60,83,1,1,1,1,'','0',0,0,0),(61,84,1,1,1,1,'','0',0,0,0),(62,85,1,1,1,1,'','0',0,0,0),(63,86,1,1,1,1,'2017-09-05 12:03:43','0',0,0,2);
/*!40000 ALTER TABLE `power` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `question`
--

DROP TABLE IF EXISTS `question`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `question` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `val` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `parid` int(11) NOT NULL,
  `sort` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `question`
--

LOCK TABLES `question` WRITE;
/*!40000 ALTER TABLE `question` DISABLE KEYS */;
INSERT INTO `question` VALUES (2,'0','是否需付費?',0,7),(4,'4.html','老師',2,0),(6,'0','老師應徵須知',0,8),(7,'0','案主應徵須知',0,6),(8,'0','老師常見問題',0,4),(10,'0','案主常見問題',0,5),(11,'0','使用流程',0,2),(12,'0','會員中心功能',0,3),(15,'15.html','案主/家長',2,0),(16,'16.html','老師找學生',11,0),(17,'17.html','案主找老師',11,0),(18,'18.html','應徵準備',8,0),(19,'19.html','電話應徵',8,0),(20,'20.html','面試應徵',8,0),(21,'21.html','正式錄取',8,0),(22,'0','會員須知',0,1);
/*!40000 ALTER TABLE `question` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reaction`
--

DROP TABLE IF EXISTS `reaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reaction` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `addtime` varchar(255) NOT NULL,
  `texts` text NOT NULL,
  `isread` int(11) NOT NULL,
  `identity` varchar(11) NOT NULL,
  `reactions` varchar(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reaction`
--

LOCK TABLES `reaction` WRITE;
/*!40000 ALTER TABLE `reaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `reaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resume`
--

DROP TABLE IF EXISTS `resume`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resume` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `numbers` varchar(255) NOT NULL,
  `uid` int(11) NOT NULL,
  `addtime` varchar(255) NOT NULL,
  `lastedit` varchar(255) NOT NULL,
  `views` int(11) NOT NULL,
  `deal` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resume`
--

LOCK TABLES `resume` WRITE;
/*!40000 ALTER TABLE `resume` DISABLE KEYS */;
INSERT INTO `resume` VALUES (30,'051048081',81,'2017-09-05 12:27:13','2017-09-05 12:33:51',4,0,0);
/*!40000 ALTER TABLE `resume` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resume_category`
--

DROP TABLE IF EXISTS `resume_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resume_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resume_category`
--

LOCK TABLES `resume_category` WRITE;
/*!40000 ALTER TABLE `resume_category` DISABLE KEYS */;
INSERT INTO `resume_category` VALUES (1,'科目'),(2,'教學地點'),(3,'對象'),(4,'教學經驗'),(5,'經驗'),(6,'教學方式'),(7,'試教意願'),(8,'學歷'),(9,'狀態'),(10,'學校'),(11,'就學開始'),(12,'就學結束'),(13,'留學經歷'),(14,'身分'),(15,'語言認證'),(16,'其他'),(17,'科系'),(18,'學校排名'),(19,'檔案');
/*!40000 ALTER TABLE `resume_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resume_list`
--

DROP TABLE IF EXISTS `resume_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resume_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reid` int(11) NOT NULL,
  `rid` int(11) NOT NULL,
  `val` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1307 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resume_list`
--

LOCK TABLES `resume_list` WRITE;
/*!40000 ALTER TABLE `resume_list` DISABLE KEYS */;
INSERT INTO `resume_list` VALUES (1278,30,15,'TOEIC,藍色(730~855)'),(1279,30,19,'1278,0,0,0'),(1287,30,10,'國立臺灣海洋大學'),(1288,30,18,'17'),(1289,30,5,'dewjijewoif23\r\n\r\n\r\nsdqwdq'),(1290,30,11,'2017-09-05'),(1291,30,12,'2017-09-05'),(1292,30,16,'qwfqwf21\r\n\r\nsweqwrqw'),(1293,30,17,'sadqw'),(1294,30,4,'一~三年'),(1295,30,6,'面對面上課'),(1296,30,7,'願意'),(1297,30,8,'大學學院'),(1298,30,9,'畢業'),(1299,30,14,'教師'),(1300,30,1,'美術藝術,建築'),(1301,30,1,'社會,國高中地理'),(1302,30,2,'嘉義縣,六腳鄉'),(1303,30,2,'新竹縣,寶山鄉'),(1304,30,3,'學齡前兒童,NT201~NT500'),(1305,30,3,'大學生,NT801~NT1000'),(1306,30,13,'非洲,四年以上');
/*!40000 ALTER TABLE `resume_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `salary`
--

DROP TABLE IF EXISTS `salary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `salary` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `val` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `salary`
--

LOCK TABLES `salary` WRITE;
/*!40000 ALTER TABLE `salary` DISABLE KEYS */;
INSERT INTO `salary` VALUES (1,'0~200'),(2,'201~500'),(3,'501~800'),(4,'801~1000'),(5,'1001');
/*!40000 ALTER TABLE `salary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `school`
--

DROP TABLE IF EXISTS `school`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `school` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `num` varchar(255) NOT NULL,
  `val` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `school`
--

LOCK TABLES `school` WRITE;
/*!40000 ALTER TABLE `school` DISABLE KEYS */;
INSERT INTO `school` VALUES (1,'16','台灣大學'),(2,'15','政治大學'),(3,'14','交通大學'),(4,'13','清華大學'),(5,'12','成功大學'),(6,'11','陽明大學'),(7,'10','中央大學'),(8,'9','中山大學'),(9,'8','中正大學'),(10,'7','中興大學'),(11,'6','高雄醫學大學'),(12,'5','中山醫藥大學'),(13,'4','中國醫藥大學'),(14,'3','輔仁大學'),(15,'2','東吳大學'),(16,'1','淡江大學'),(17,'10','台灣科技大學'),(18,'9','台灣藝術大學'),(19,'8','台北科技大學'),(20,'7','台北藝術大學'),(21,'6','高雄應用科技大學'),(22,'5','屏東科技大學'),(23,'4','台北商業大學'),(24,'3','高雄第一科技大學'),(25,'2','雲林科技大學'),(26,'1','台中科技大學');
/*!40000 ALTER TABLE `school` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schools`
--

DROP TABLE IF EXISTS `schools`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schools` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `num` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=160 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schools`
--

LOCK TABLES `schools` WRITE;
/*!40000 ALTER TABLE `schools` DISABLE KEYS */;
INSERT INTO `schools` VALUES (1,15,'國立政治大學'),(2,13,'國立清華大學'),(3,16,'國立臺灣大學'),(4,0,'國立臺灣師範大學'),(5,12,'國立成功大學'),(6,7,'國立中興大學'),(7,14,'國立交通大學'),(8,10,'國立中央大學'),(9,9,'國立中山大學'),(10,0,'國立臺灣海洋大學'),(11,8,'國立中正大學'),(12,0,'國立高雄師範大學'),(13,0,'國立彰化師範大學'),(14,11,'國立陽明大學'),(15,0,'國立臺北大學'),(16,0,'國立嘉義大學'),(17,0,'國立高雄大學'),(18,0,'國立東華大學'),(19,0,'國立暨南國際大學'),(20,10,'國立臺灣科技大學'),(21,2,'國立雲林科技大學'),(22,5,'國立屏東科技大學'),(23,8,'國立臺北科技大學'),(24,3,'國立高雄第一科技大學'),(25,6,'國立高雄應用科技大學'),(26,7,'國立臺北藝術大學'),(27,9,'國立臺灣藝術大學'),(28,0,'國立臺東大學'),(29,0,'國立宜蘭大學'),(30,0,'國立聯合大學'),(31,0,'國立虎尾科技大學'),(32,0,'國立高雄海洋科技大學'),(33,0,'國立臺南藝術大學'),(34,0,'國立臺南大學'),(35,0,'國立臺北教育大學'),(36,0,'國立新竹教育大學'),(37,0,'國立臺中教育大學'),(38,0,'國立澎湖科技大學'),(39,0,'國立勤益科技大學'),(40,0,'國立體育大學'),(41,0,'國立臺北護理健康大學'),(42,0,'國立高雄餐旅大學'),(43,0,'國立金門大學'),(44,0,'國立臺灣體育運動大學'),(45,1,'國立臺中科技大學'),(46,4,'國立臺北商業大學'),(47,0,'國立屏東大學'),(48,0,'國立臺灣戲曲學院'),(49,0,'國立空中大學'),(50,0,'東海大學'),(51,3,'輔仁大學'),(52,2,'東吳大學'),(53,0,'中原大學'),(54,1,'淡江大學'),(55,0,'中國文化大學'),(56,0,'逢甲大學'),(57,0,'靜宜大學'),(58,0,'長庚大學'),(59,0,'元智大學'),(60,0,'中華大學'),(61,0,'大葉大學'),(62,0,'華梵大學'),(63,0,'義守大學'),(64,0,'世新大學'),(65,0,'銘傳大學'),(66,0,'實踐大學'),(67,0,'朝陽科技大學'),(68,6,'高雄醫學大學'),(69,0,'南華大學'),(70,0,'真理大學'),(71,0,'大同大學'),(72,0,'南臺科技大學'),(73,0,'崑山科技大學'),(74,0,'嘉南藥理大學'),(75,0,'樹德科技大學'),(76,0,'慈濟大學'),(77,0,'臺北醫學大學'),(78,5,'中山醫學大學'),(79,0,'龍華科技大學'),(80,0,'輔英科技大學'),(81,0,'明新科技大學'),(82,0,'長榮大學'),(83,0,'弘光科技大學'),(84,4,'中國醫藥大學'),(85,0,'健行科技大學'),(86,0,'正修科技大學'),(87,0,'萬能科技大學'),(88,0,'玄奘大學'),(89,0,'建國科技大學'),(90,0,'明志科技大學'),(91,0,'高苑科技大學'),(92,0,'大仁科技大學'),(93,0,'聖約翰科技大學'),(94,0,'嶺東科技大學'),(95,0,'中國科技大學'),(96,0,'中臺科技大學'),(97,0,'亞洲大學'),(98,0,'開南大學'),(99,0,'佛光大學'),(100,0,'台南應用科技大學'),(101,0,'遠東科技大學'),(102,0,'元培醫事科技大學'),(103,0,'景文科技大學'),(104,0,'中華醫事科技大學'),(105,0,'東南科技大學'),(106,0,'德明財經科技大學'),(107,0,'明道大學'),(108,0,'南開科技大學'),(109,0,'中華科技大學'),(110,0,'僑光科技大學'),(111,0,'育達科技大學'),(112,0,'美和科技大學'),(113,0,'吳鳳科技大學'),(114,0,'環球科技大學'),(115,0,'台灣首府大學'),(116,0,'中州科技大學'),(117,0,'修平科技大學'),(118,0,'長庚科技大學'),(119,0,'臺北城市科技大學'),(120,0,'大華科技大學'),(121,0,'醒吾科技大學'),(122,0,'南榮科技大學'),(123,0,'文藻外語大學'),(124,0,'華夏科技大學'),(125,0,'慈濟科技大學'),(126,0,'致理科技大學'),(127,0,'康寧大學'),(128,0,'中信金融管理學院'),(129,0,'大漢技術學院'),(130,0,'和春技術學院'),(131,0,'亞東技術學院'),(132,0,'南亞技術學院'),(133,0,'稻江科技暨管理學院'),(134,0,'德霖技術學院'),(135,0,'蘭陽技術學院'),(136,0,'黎明技術學院'),(137,0,'東方設計學院'),(138,0,'經國管理暨健康學院'),(139,0,'崇右技術學院'),(140,0,'大同技術學院'),(141,0,'亞太創意技術學院'),(142,0,'臺灣觀光學院'),(143,0,'馬偕醫學院'),(144,0,'法鼓文理學院'),(145,0,'台北海洋技術學院'),(146,0,'中華浸信會基督教台灣浸會神學院'),(147,0,'臺北基督學院'),(148,0,'一貫道天皇學院'),(149,0,'台灣神學研究學院'),(150,0,'一貫道崇德學院'),(151,0,'臺北市立大學'),(152,0,'高雄市立空中大學'),(153,0,'中華民國陸軍軍官學校'),(154,0,'海軍軍官學校'),(155,0,'中華民國空軍軍官學校'),(156,0,'國防大學'),(157,0,'中央警察大學'),(158,0,'國防醫學院'),(159,0,'國立空軍航空技術學院');
/*!40000 ALTER TABLE `schools` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `search`
--

DROP TABLE IF EXISTS `search`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `search` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `oid` int(11) NOT NULL,
  `vid` int(11) NOT NULL,
  `val` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `search`
--

LOCK TABLES `search` WRITE;
/*!40000 ALTER TABLE `search` DISABLE KEYS */;
INSERT INTO `search` VALUES (1,1,1,'學齡前兒童'),(2,1,2,'國小生'),(3,1,3,'國中生'),(4,1,4,'高中生'),(5,1,5,'大學生'),(6,1,6,'社會人士');
/*!40000 ALTER TABLE `search` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `search_case`
--

DROP TABLE IF EXISTS `search_case`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `search_case` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `caseid` int(11) NOT NULL,
  `obj` varchar(11) NOT NULL,
  `sub` varchar(11) NOT NULL,
  `area` varchar(11) NOT NULL,
  `exper` varchar(11) NOT NULL,
  `sala` varchar(11) NOT NULL,
  `timess` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `search_case`
--

LOCK TABLES `search_case` WRITE;
/*!40000 ALTER TABLE `search_case` DISABLE KEYS */;
INSERT INTO `search_case` VALUES (22,22,'4','75','141','1','5','3'),(23,23,'2','53','51','1','5','3'),(24,24,'4','4','8','5','3','2'),(25,25,'3','5','2','3','5','4');
/*!40000 ALTER TABLE `search_case` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `search_teacher`
--

DROP TABLE IF EXISTS `search_teacher`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `search_teacher` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `resumeid` int(11) NOT NULL,
  `obj` varchar(255) NOT NULL,
  `sub` varchar(255) NOT NULL,
  `area` varchar(255) NOT NULL,
  `exper` varchar(255) NOT NULL,
  `sala` varchar(255) NOT NULL,
  `other` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `search_teacher`
--

LOCK TABLES `search_teacher` WRITE;
/*!40000 ALTER TABLE `search_teacher` DISABLE KEYS */;
INSERT INTO `search_teacher` VALUES (23,25,'2,4','5,36','203,164','3','2,3','1'),(25,28,'3','7','201','2','3','1,2,4'),(27,30,'1,5','75,33','182,69','3','2,4','1');
/*!40000 ALTER TABLE `search_teacher` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subjects`
--

DROP TABLE IF EXISTS `subjects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subjects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `val` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subjects`
--

LOCK TABLES `subjects` WRITE;
/*!40000 ALTER TABLE `subjects` DISABLE KEYS */;
INSERT INTO `subjects` VALUES (1,'伴讀'),(2,'保姆'),(3,'國文'),(4,'英文'),(5,'數學'),(6,'自然'),(7,'社會'),(8,'本土方言'),(9,'外國語言'),(10,'音樂'),(11,'美術藝術'),(12,'運動'),(13,'電腦'),(14,'舞蹈'),(15,'專業科目'),(16,'興趣嗜好'),(17,'創業技能與其他職訓');
/*!40000 ALTER TABLE `subjects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `week`
--

DROP TABLE IF EXISTS `week`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `week` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `val` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `week`
--

LOCK TABLES `week` WRITE;
/*!40000 ALTER TABLE `week` DISABLE KEYS */;
INSERT INTO `week` VALUES (1,'週一'),(2,'週二'),(3,'週三'),(4,'週四'),(5,'週五'),(6,'週六'),(7,'週日');
/*!40000 ALTER TABLE `week` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-09-05 17:14:23

